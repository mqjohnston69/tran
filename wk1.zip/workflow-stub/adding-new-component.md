## Generating a new component and integrating it into the application


### 1
Generate a new component using one of the provided tasks, such as `gen-component-stub` or `gen-simple-solution`


```bash
 npm run gen-component-stub -- -name new-widget

 npm run gen-simple-solution -- -name new-solution

 npm run gen-solution-page-module -- -name new-solution -pageName test-page-name
 ```

Your component will be placed as a directory in `/src/app/layout`

### 2

Add an import statement for your component module in `/src/app/.../....module.ts`


### 3

....


### 4

....

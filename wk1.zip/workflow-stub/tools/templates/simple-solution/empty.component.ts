import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-<%= componentName %>',
    templateUrl: './<%= componentName %>.component.html',
    styleUrls: ['./<%= componentName %>.component.scss']
})
export class <%= componentNameTitleCase %>Component implements OnInit {

    collapedSideBar: boolean;

    constructor() {}

    ngOnInit() {}

    receiveCollapsed($event) {
        this.collapedSideBar = $event;
    }
}

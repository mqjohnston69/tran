import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';

import { <%= componentNameTitleCase %>RoutingModule } from './<%= componentName %>-routing.module';
import { <%= componentNameTitleCase %>Component } from './<%= componentName %>.component';
import { SidebarComponent } from '../shared/components/sidebar/sidebar.component';
import { HeaderComponent } from '../shared/components/header/header.component';

@NgModule({
    imports: [
        CommonModule,
        <%= componentNameTitleCase %>RoutingModule,
        TranslateModule,
        NgbDropdownModule.forRoot()
    ],
    declarations: [<%= componentNameTitleCase %>Component, SidebarComponent, HeaderComponent]
})
export class <%= componentNameTitleCase %>Module {}

import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-<%= componentName %>-cmp',
    templateUrl: './<%= componentName %>.component.html',
    styleUrls: ['./<%= componentName %>.component.scss']
})
export class <%= componentNameTitleCase %>Component implements OnInit {
    constructor() {}

    ngOnInit() {}
}

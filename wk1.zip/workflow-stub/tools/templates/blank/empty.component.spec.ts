import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { <%= componentNameTitleCase %>Component } from './<%= componentName %>.component';

describe('<%= componentNameTitleCase %>Component', () => {
    let component: <%= componentNameTitleCase %>Component;
    let fixture: ComponentFixture<<%= componentNameTitleCase %>Component>;

    beforeEach(
        async(() => {
            TestBed.configureTestingModule({
                declarations: [<%= componentNameTitleCase %>Component]
            }).compileComponents();
        })
    );

    beforeEach(() => {
        fixture = TestBed.createComponent(<%= componentNameTitleCase %>Component);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});

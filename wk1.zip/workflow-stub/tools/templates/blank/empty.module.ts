import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { <%= componentNameTitleCase %>RoutingModule } from './<%= componentName %>-routing.module';
import { <%= componentNameTitleCase %>Component } from './<%= componentName %>.component';

@NgModule({
    imports: [CommonModule, <%= componentNameTitleCase %>RoutingModule],
    declarations: [<%= componentNameTitleCase %>Component]
})
export class <%= componentNameTitleCase %>Module {}

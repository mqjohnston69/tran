import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { <%= componentNameTitleCase %>Component } from './<%= componentName %>.component';

const routes: Routes = [
    {
        path: '',
        component: <%= componentNameTitleCase %>Component
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class <%= componentNameTitleCase %>RoutingModule {}

import { <%= componentNameTitleCase %>Module } from './<%= componentName %>.module';

describe('<%= componentNameTitleCase %>Module', () => {
    let <%= componentName %>Module: <%= componentNameTitleCase %>Module;

    beforeEach(() => {
        <%= componentName %>Module = new <%= componentNameTitleCase %>Module();
    });

    it('should create an instance', () => {
        expect(<%= componentName %>Module).toBeTruthy();
    });
});

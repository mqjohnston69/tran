﻿import { IEventData } from '../interfaces/IEventData';

export class EventDataModel implements IEventData {
  public eventName = '';
  public dataNum1 = -1;
  public dataNum2 = -1;
  public bool1 = false;
  public dataStr1 = '';
  public dataStr2 = '';
  public data: any;
  constructor(
  ) {
    //
  }
}



import {
    Component, OnInit, Input, AfterViewInit, OnDestroy, Output, EventEmitter,
    NgZone, ElementRef, ViewChild, HostListener
} from '@angular/core';
import * as _ from 'lodash';

import { Router } from '@angular/router';
import { NodeViewModel } from './node.view-model';
import { ConnectorViewModel } from './connector.view-model';
import { ConnectionViewModel } from './connection.view-model';
import { EventDataModel  } from './types/models/event-data.model';
import { DropEvent } from 'ng-drag-drop';
import { FlowChartHelperService } from './services/flow-chart-helper.service';

import { D3Service } from './d3/d3.service';

@Component({
    moduleId: module.id,
    selector: 'flow-chart-cmp',
    templateUrl: 'flow-chart.component.html',
    styleUrls: ['./flow-chart.component.scss']
})

export class FlowChartComponent implements OnInit, AfterViewInit, OnDestroy {
    @ViewChild('svgElement') svgElement: ElementRef;

    templateList = new Array<any>();

    @Input() set workflowData(workflowData: any) {
        this.workflow = workflowData;
        if (this.ngOnInitCompleted) {
            this.loadWorkflow();
        }
    }

    @Input() set canPanZoom(canPanZoom: boolean) {
        /* ----------------------------------------------------
            We want the ability to control when the component will
            be allowed to have pan zoom capabilities as we want to make
            the edit of a workflow more seemless.
           ----------------------------------------------------*/
    }

    @Input() displayMode: any;
    @Input() design = false;
    @Input() set selectedNode(selectedNode: string) {
        if (selectedNode !== this.selectedNodeName) {
            this.selectedNodeName = '';
        }
    }

    @Output('selectedNodeChange') selectedNodeChange = new EventEmitter<EventDataModel>();

    @Output('nodesChanged') nodesChanged = new EventEmitter<EventDataModel>();
    @Output('itemsDeleted') itemsDeleted = new EventEmitter<EventDataModel>();
    @Output('connectionAdded') connectionAdded = new EventEmitter<EventDataModel>();
    @Output('confirmDelete') confirmDelete = new EventEmitter<EventDataModel>();

    @Output('navigationRequested') navigationRequested = new EventEmitter<EventDataModel>();

    canZoom = false;

    workflow: any;
    flowChartPanZoom: any;
    viewBox = '0 0 1700 600';
    queueTransform = 'translate(0,5) scale(0.75)';
    width = '100%';
    height = '500';

    // Options
    showOptions = false;
    scroll = false;
    tangent = false;
    createQueueOnDrop = true;
    showUserDefinedLayout = false;

    svgId: string;
    workflowID = 0;
    selectedNodeName = '';
    dropX = 0;                                          //  ToDo:  Remove use of this variable
    dropY = 0;                                          //  ToDo:  Remove use of this variable
    ngOnInitCompleted = false;

    newNodeName = '';                                   //  Name of the newly add Node.
    nameMaxLength = 26;


    displayDialog = false;
    dialogHeaderText = '[DialogHeader]';

    connectorSize = 10;
    nodes: NodeViewModel[];
    connections: any;

    lastDropEvent: any;                         // The last drop event.
    curveLines = false;                 //  Option for curving the connection lines
    //  Used to determine if we show flowchart options or not

    draggingConnection = false;
    dragSelecting = false;
    mouseOverConnector = null;
    mouseOverConnection = null;
    mouseOverNode = {
        data: {
            id: -1
        }
    };

    connectionClass = 'connection';
    connectorClass = 'connector';
    nodeClass = 'node';

    dragPoint1 = { x: 12, y: 100 };
    dragPoint2 = { x: 12, y: 500 };

    dragSelectionRect = {
        x: 0,
        y: 0,
        width: 100,
        height: 100,
    };

    dragSelectionStartPoint;

    sourceNode = null;
    destinationNode = null;

    moveNode: any;
    moveElement: any;
    offsetX;
    offsetY;
    currentMoveId;
    lastMouseCoords;

    defaultNodeWidth = 250;                     // Width of a node.
    nodeNameHeight = 40;                        // Amount of space reserved for displaying the node's name.
    connectorHeight = 35;                       // Height of a connector in a node.

    constructor(private router: Router,
        private zone: NgZone,
        public d3Service: D3Service,
        // private toasterService: ToasterService,
        public flowChartHelperService: FlowChartHelperService) {

    }

    ngOnInit() {
        this.loadWorkflow();
        this.ngOnInitCompleted = true;
    }

    loadWorkflow() {
        let chartDataModel = this.workflow;
        if (this.svgId === undefined) {
            this.svgId = 'svg' + this.flowChartHelperService.getSvgId(); // NOTE:  This needs to be unique.
        }
        if ((this.workflow === undefined) || (this.workflow.workflowID === undefined)) {
            return;
        }
        this.workflowID = this.workflow.workflowID;
        if (this.design) {
            this.queueTransform = 'translate(25,0) scale(1)';
        }
        // Create a view-model for nodes.
        this.nodes = this.flowChartHelperService.createNodesViewModel(chartDataModel.nodes);

        // Create a view-model for connections.
        this.connections = this._createConnectionsViewModel(chartDataModel.connections);

        this.width = '100%';

        if (this.displayMode === 'CARD') {
            this.height = '300';
        } else {
            this.height = this.workflow.desiredHeight;
        }

        if (!this.ngOnInitCompleted) {
            if (this.workflow.desiredWidth < 600) {
                // nothing for now
            } else {
                this.viewBox = '0 0' + ' ' + this.workflow.desiredWidth + ' ' + this.workflow.desiredHeight;
            }

            // if(this.displayMode==='LIST') {
            //     this.viewBox='0 0' + ' ' + this.workflow.desiredWidth + ' ' + this.workflow.desiredHeight;
            //     this.width='100%';
            //     this.height= this.workflow.desiredHeight;
            // }
            // else{

            //     this.viewBox='';
            //     this.width= this.workflow.desiredWidth;
            //     this.height= this.workflow.desiredHeight;
            // }

            if (this.displayMode === 'DETAILS') {
                this.viewBox = '0 0' + ' ' + this.workflow.desiredWidth + ' ' + this.workflow.desiredHeight;
                this.width = this.workflow.desiredWidth;
                this.height = this.workflow.desiredHeight;
                this.scroll = true;
            }
        }
    }

    navigateToWorkflow(node) {
        let eventData = new EventDataModel();
        eventData.eventName = 'navigationRequested';
        eventData.data = {
            translatorName: node.data.name,
            workflowName: this.workflow.name,
        };

        this.navigationRequested.emit(eventData);
    }

    deleteConnections(connectionsToDelete) {
        let newConnectionViewModels = [];
        let newConnectionDataModels = [];

        for (let connectionIndex = 0; connectionIndex < this.connections.length; ++connectionIndex) {

            let connection = this.connections[connectionIndex];

            let found = false;

            for (let connectionToDelete of connectionsToDelete) {
                if (connection.data.dest.nodeID === connectionToDelete.data.dest.nodeID &&
                    connection.data.source.nodeID === connectionToDelete.data.source.nodeID) {
                    found = true;
                }
            }

            if (!found) {
                newConnectionViewModels.push(connection);
                newConnectionDataModels.push(connection.data);
            }


            // if (connectionsToDelete
            //     (connection.data.source.nodeID) === -1 &&
            //     connectionsToDelete.indexOf(connection.data.dest.nodeID) === -1) {

            //     newConnectionViewModels.push(connection);
            //     newConnectionDataModels.push(connection.data);
            // };

        }

        this.connections = newConnectionViewModels;
    }


    showUserDefinedLayoutModelChanged(data) {

        let userdefinedLayout = JSON.parse(this.workflow.workflowData);

        for (let node of userdefinedLayout.nodes) {
            let workflowNode = _.find(this.workflow.nodes, function (o: any) { return o.name === node.name; });
            if (workflowNode !== undefined) {
                workflowNode.x = node.x;
                workflowNode.y = node.y;
            }
        }

        // do something with new value
    }

    //
    // Compute the Y coordinate of a connector, given its index.
    //
    computeConnectorY(connectorIndex) {
        return this.nodeNameHeight + (connectorIndex * this.connectorHeight);
    }

    //
    // Compute the position of a connector in the graph.
    //
    computeConnectorPos(node, connectorIndex, inputConnector) {
        return {
            x: node.x() + (inputConnector ? 0 : node.width ? node.width() : this.defaultNodeWidth),
            y: node.y() + this.computeConnectorY(connectorIndex),
        };
    }

    //
    // Create view model for a list of data models.
    //
    createConnectorsViewModel(connectorDataModels, x, parentNode) {
        let viewModels = [];

        if (connectorDataModels) {
            for (let i = 0; i < connectorDataModels.length; ++i) {
                let connectorViewModel =
                    new ConnectorViewModel(connectorDataModels[i], x, this.computeConnectorY(i), parentNode);
                viewModels.push(connectorViewModel);
            }
        }
        return viewModels;
    }

    ngAfterViewInit(): void {
       ///
    }

    ngOnDestroy(): void {
        ///
    }

    getPathDataForConnection(connection: any) {
        let data = '';

        let curveOption = ' ';

        if (this.curveLines) {
            curveOption = 'C ';
        }

        if (this.tangent) {
            if (connection.data.source.nodePositionLevel > connection.data.dest.nodePositionLevel) {
                data = 'M ' + connection.sourceCoordX() + ', ' + connection.sourceCoordY() +
                    curveOption + ((connection.destCoordX() - 25)) + ', ' + (connection.sourceCoordY()) +
                    ' ' + (connection.destCoordX() - 25) + ', ' + connection.destCoordY() +
                    ' ' + connection.destCoordX() + ', ' + connection.destCoordY();

            } else if (connection.data.source.nodePositionLevel < connection.data.dest.nodePositionLevel) {
                data = 'M ' + connection.sourceCoordX() + ', ' + connection.sourceCoordY() +
                    curveOption + ((connection.destCoordX() - 25)) + ', ' + (connection.sourceCoordY()) +
                    ' ' + (connection.destCoordX() - 25) + ', ' + connection.destCoordY() +
                    ' ' + connection.destCoordX() + ', ' + connection.destCoordY();
            } else {
                data = 'M ' + connection.sourceCoordX() + ', ' + connection.sourceCoordY() +
                    curveOption + connection.sourceTangentX() + ', ' + connection.sourceTangentY() +
                    ' ' + connection.destTangentX() + ', ' + connection.destTangentY() +
                    ' ' + connection.destCoordX() + ', ' + connection.destCoordY();
            }
        } else {
            if (connection.data.source.nodePositionLevel > connection.data.dest.nodePositionLevel) {
                data = 'M ' + connection.sourceCoordX() + ', ' + connection.sourceCoordY() +
                    ' ' + connection.destCoordX() + ', ' + connection.destCoordY();

            } else if (connection.data.source.nodePositionLevel < connection.data.dest.nodePositionLevel) {
                data = 'M ' + connection.sourceCoordX() + ', ' + connection.sourceCoordY() +
                    ' ' + connection.destCoordX() + ', ' + connection.destCoordY();
            } else {
                data = 'M ' + connection.sourceCoordX() + ', ' + connection.sourceCoordY() +
                    ' ' + connection.destCoordX() + ', ' + connection.destCoordY();
            }
        }

        return data;
    }

    translate(x, y) {
        return 'translate(' + x + ',' + y + ')';
    }

    checkType(node, type: string) {
        if (node.data.type.replace(' ', '').toLowerCase() === type.replace(' ', '').toLowerCase()) {
            return true;
        } else {
            return false;
        }
    }

    getNodeName(node): string {
        let nodeName = node.name();
        if (nodeName.length < 25 || this.selectedNodeName === nodeName) {
            return nodeName;
        }
        return nodeName.substr(0, 25) + '...';
    }

    nodeClicked(node: any) {
        this.selectedNodeName = node.data.name;
        let eventData = new EventDataModel();
        eventData.eventName = 'WorkflowNodeSelected';
        eventData.dataNum1 = this.workflowID;
        eventData.data = node.data;

        this.selectedNodeChange.emit(eventData);

    }

    checkIfNodeIsSelected(node) {
        if (node.selected()) {
            return 'selected-node-rect';
        } else {
            return 'node-rect';
        }
    }

    checkIfNodeIsMouseOverNode(node) {
        if (node.selected()) {
            return 'mouseover-node-rect';
        } else {
            return '';
        }
    }

    checkIfConnectionIsSelected(connection) {
        if (connection.selected()) {
            return 'selected-connection-line';
        } else {
            return 'connection-line';
        }
    }

    checkIfIsListDisplayMode() {
        if (this.displayMode === 'LIST') {
            return 'draggable-container-list-item';
        } else {
            return '';
        }
    }

    getNodeFill(node) {
        if (node.data.type === 'WorkflowConnector') {
            return '#fff';
        } else if (node.data.type === 'Default') {
            return '#fad2aa';
        }

        return '#fad2aa';
    }

    onDrop(event: DropEvent) {

        //  Set the last drop event so we can place the node correctly once named.
        this.lastDropEvent = event;

        if (!this.design) {
            return;     // Not in edit mode
        }
        if (event.dragData && event.dragData.children) {
            return;     // Not the template node
        }

        let prefix = '';
        if (this.workflow && this.workflow.workflowName && this.workflow.workflowName.length > 0) {
            prefix = this.workflow.workflowName.replace(/[^0-9a-z]/gi, '');
            if (prefix.length > 10) {
                prefix = prefix.substr(0, 10);
            }
        }

        this.newNodeName = prefix + event.dragData.label.replace(/[^0-9a-z]/gi, '') + this.flowChartHelperService.getSvgId();

    }

    //
    // Find a specific node within the chart.
    //
    findNode(nodeID) {

        for (let i = 0; i < this.nodes.length; ++i) {
            let node = this.nodes[i];
            if (node.data.id === nodeID) {
                return node;
            }
        }

        throw new Error('Failed to find node ' + nodeID);
    }

    //
    // Find a specific input connector within the chart.
    //
    findInputConnector(nodeID, connectorIndex) {

        let node = this.findNode(nodeID);

        if (!node.inputConnectors || node.inputConnectors.length <= connectorIndex) {
            throw new Error('Node ' + nodeID + 'has invalid input connectors.');
        }

        return node.inputConnectors[connectorIndex];
    }

    //
    // Find a specific output connector within the chart.
    //
    findOutputConnector = function (nodeID, connectorIndex) {

        let node = this.findNode(nodeID);

        if (!node.outputConnectors || node.outputConnectors.length <= connectorIndex) {
            throw new Error('Node ' + nodeID + ' has invalid output connectors.');
        }

        return node.outputConnectors[connectorIndex];
    };

    //
    // Create a view model for connection from the data model.
    //
    _createConnectionViewModel = function (connectionDataModel) {

        let sourceConnector = this.findOutputConnector(connectionDataModel.source.nodeID, connectionDataModel.source.connectorIndex);
        let destConnector = this.findInputConnector(connectionDataModel.dest.nodeID, connectionDataModel.dest.connectorIndex);
        return new ConnectionViewModel(connectionDataModel, sourceConnector, destConnector);
    };

    //
    // Wrap the connections data-model in a view-model.
    //
    _createConnectionsViewModel(connectionsDataModel) {

        let connectionsViewModel = [];

        if (connectionsDataModel) {
            for (let i = 0; i < connectionsDataModel.length; ++i) {
                connectionsViewModel.push(this._createConnectionViewModel(connectionsDataModel[i]));
            }
        }

        return connectionsViewModel;
    }

    //
    // Deselect all nodes and connections in the chart.
    //
    deselectAll() {

        let nodes = this.nodes;
        for (let i = 0; i < nodes.length; ++i) {
            let node = nodes[i];
            node.deselect();
        }

        let connections = this.connections;
        for (let i = 0; i < connections.length; ++i) {
            let connection = connections[i];
            connection.deselect();
        }
    }

    //
    // Hit test and retreive node and connector that was hit at the specified coordinates.
    //
    hitTest(clientX, clientY) {
        //
        // Retreive the element the mouse is currently over.
        //
        return document.elementFromPoint(clientX, clientY);
    }

    nodeMouseOver(event, node) {
        this.mouseOverNode = node;

        // var svg_elem = this.svgElement.nativeElement;

        // svg_elem.appendChild(event.target);
    }

    connectionMouseDown(evt, connection) {
        if (evt.ctrlKey) {
            connection.toggleSelected();
        } else {
            this.deselectAll();
            connection.select();
        }

        // Don't let the chart handle the mouse down.
        evt.stopPropagation();
        evt.preventDefault();
    }

    @HostListener('document:keydown', ['$event']) onKeydownHandler(event: any) {
        if (!this.design)  {
            return;
        }

        if (event.keyCode === 46) {
            if (event.ctrlKey) {
              // this.deleteSelected();
              this.confirmDeleteAction();
            }
        }

        if (event.keyCode === 79) {
            if (event.ctrlKey && event.altKey === true) {
                this.toggleOptions();
            }
        }
    }

    onSvgRootMouseDown(event) {
        this.dragSelecting = true;
        let startPoint = this.translateCoordinates(event.pageX, event.pageY);
        this.dragSelectionStartPoint = startPoint;
        this.dragSelectionRect = {
            x: startPoint.x,
            y: startPoint.y,
            width: 0,
            height: 0,
        };

        this.deselectAll();
    }

    onSvgRootMouseUp(event) {
        this.dragSelecting = false;
    }

    public handleRootDragPositionChange(newPosition: any): void {
        let startPoint = this.dragSelectionStartPoint;
        let curPoint = this.translateCoordinates(newPosition.event.clientX, newPosition.event.clientY);

        this.dragSelectionRect = {
            x: curPoint.x > startPoint.x ? startPoint.x : curPoint.x,
            y: curPoint.y > startPoint.y ? startPoint.y : curPoint.y,
            width: curPoint.x > startPoint.x ? curPoint.x - startPoint.x : startPoint.x - curPoint.x,
            height: curPoint.y > startPoint.y ? curPoint.y - startPoint.y : startPoint.y - curPoint.y,
        };
    }

    onRootDragMoveComplete(event) {
        this.dragSelecting = false;
        this.applySelectionRect(this.dragSelectionRect);
    }

    applySelectionRect(selectionRect) {
        this.deselectAll();
        for (let i = 0; i < this.nodes.length; ++i) {
            let node = this.nodes[i];
            if (node.x() >= selectionRect.x &&
                node.y() >= selectionRect.y &&
                node.x() + node.width() <= selectionRect.x + selectionRect.width &&
                node.y() + node.height() <= selectionRect.y + selectionRect.height) {
                // Select nodes that are within the selection rect.
                node.select();
            }
        }

        for (let i = 0; i < this.connections.length; ++i) {
            let connection = this.connections[i];
            if (connection.source.parentNode().selected() &&
                connection.dest.parentNode().selected()) {
                // Select the connection if both its parent nodes are selected.
                connection.select();
            }
        }

    }

    nodeMouseDown(event, node) {

        const mouseX = event.clientX;
        const mouseY = event.clientY;
        this.offsetX = node.data.x - mouseX;
        this.offsetY = node.data.y - mouseY;
        this.currentMoveId = node.id;

        this.moveNode = node;

        this.moveElement = event.target;

        this.lastMouseCoords = this.translateCoordinates(event.pageX, event.pageY);

        if (event.ctrlKey) {
            node.toggleSelected();
        } else {
            this.deselectAll();
            node.select();
        }

        //////////////////////////
        this.selectedNodeName = node.data.name;
        let eventData = new EventDataModel();
        eventData.eventName = 'WorkflowNodeSelected';
        eventData.dataNum1 = this.workflowID;
        eventData.data = node.data;

        this.selectedNodeChange.emit(eventData);

        // Don't let the chart handle the mouse down.
        event.stopPropagation();
        event.preventDefault();
    }

    //
    // Get the array of nodes that are currently selected.
    //
    getSelectedNodes() {
        let selectedNodes = [];

        for (let i = 0; i < this.nodes.length; ++i) {
            let node = this.nodes[i];
            if (node.selected()) {
                selectedNodes.push(node);
            }
        }
        return selectedNodes;
    }

    public handleNodePositionChange(newPosition: any, node: any): void {
        if (!this.design) {
            return;
        }
        let curCoords = this.translateCoordinates(newPosition.event.pageX, newPosition.event.pageY);
        let deltaX = curCoords.x - this.lastMouseCoords.x;
        let deltaY = curCoords.y - this.lastMouseCoords.y;

        this.updateSelectedNodesLocation(deltaX, deltaY);

        this.lastMouseCoords = curCoords;
    }

    //
    // Update the location of the node and its connectors.
    //
    updateSelectedNodesLocation(deltaX, deltaY) {

        let selectedNodes = this.getSelectedNodes();

        for (let i = 0; i < selectedNodes.length; ++i) {
            let node = selectedNodes[i];
            node.data.x += deltaX;
            node.data.y += deltaY;
        }
    }

    handleoutputConnectorPositionChange(newPosition: any, node, connector: any): void {

        this.sourceNode = node;

        let relitivePoint = this.translateCoordinates(newPosition.event.clientX, newPosition.event.clientY);

        this.dragPoint2.x = relitivePoint.x;
        this.dragPoint2.y = relitivePoint.y;

        let mouseOverElement = this.hitTest(newPosition.event.clientX, newPosition.event.clientY);
        if (mouseOverElement === null) {
            // Mouse isn't over anything, just clear all.
            return;
        }
    }

    inputConnectorMouseOver(event, node, connector) {
        this.destinationNode = node;
    }

    inputConnectorMouseOut() {
        this.destinationNode = null;
    }

    onMoveComplete(event) {
        this.draggingConnection = false;

        if (this.sourceNode === null || this.destinationNode === null) {
            return;
        }

        let newConnectionDataModel = {
            name: this.sourceNode.data.name + '_' + this.destinationNode.data.name,
            source: {
                nodeID: this.sourceNode.data.id,
                nodeX: this.sourceNode.data.x,
                nodeY: this.sourceNode.data.y,
                nodeWidth: this.sourceNode.data.width,
                nodePositionIndex: this.sourceNode.data.positionIndex,
                nodePositionLevel: this.sourceNode.data.positionLevel,
                connectorIndex: 0,
            },
            dest: {
                nodeID: this.destinationNode.data.id,
                nodeX: this.destinationNode.data.x,
                nodeY: this.destinationNode.data.y,
                nodeWidth: this.destinationNode.data.width,
                nodePositionIndex: this.destinationNode.data.positionIndex,
                nodePositionLevel: this.destinationNode.data.positionLevel,
                connectorIndex: 0,
            }
        };

        let newconnectionVM = (this._createConnectionViewModel(newConnectionDataModel));

        //  Add Connection
        this.connections.push(
            newconnectionVM
        );


        let eventData = new EventDataModel();
        eventData.eventName = 'connectionAdded';
        eventData.data = {
            connectionDataModel: newConnectionDataModel,
            sourceNode: this.sourceNode,
            destNode: this.destinationNode,
        };

        this.connectionAdded.emit(eventData);
    }

    onOutputConnectorClicked(event, connector) {
        if (!this.design) {
            return;
        }
        event.preventDefault();
        this.dragPoint1.x = connector.parentNode().x() + connector.x();
        this.dragPoint1.y = connector.parentNode().y() + connector.y();
        this.dragPoint2.x = connector.parentNode().x() + connector.x();
        this.dragPoint2.y = connector.parentNode().y() + connector.y();
        this.draggingConnection = true;
    }

    outputConnectorMouseDown(event, connector) {

        if (!this.design) {
            return;
        }

        this.dragPoint1.x = connector.parentNode().x() + connector.x();
        this.dragPoint1.y = connector.parentNode().y() + connector.y();
        this.dragPoint2.x = connector.parentNode().x() + connector.x();
        this.dragPoint2.y = connector.parentNode().y() + connector.y();
        this.draggingConnection = true;

        // Don't let the chart handle the mouse down.
        event.stopPropagation();
        event.preventDefault();
    }

    outputConnectorMouseUp(event) {
        this.draggingConnection = false;
    }

    getPathDataForDraging(connection: any) {
        let data = '';
        data = 'M ' + this.dragPoint1.x + ', ' + this.dragPoint1.y +
            ' ' + this.dragPoint2.x + ', ' + this.dragPoint2.y;
        return data;
    }

    //
    // Translate the coordinates so they are relative to the svg element.
    //
    translateCoordinates = function (x, y) {
        let svg_elem = this.svgElement.nativeElement;
        let matrix = svg_elem.getScreenCTM();
        let point = svg_elem.createSVGPoint();
        point.x = x;
        point.y = y;
        point = point.matrixTransform(matrix.inverse());

        if (this.d3Service.lastZoomEvent !== null) {
            point.x = (point.x - this.d3Service.lastZoomEvent.x) / this.d3Service.lastZoomEvent.k;
            point.y = (point.y - this.d3Service.lastZoomEvent.y) / this.d3Service.lastZoomEvent.k;
        }

        // if(this.canZoom) {
        // var pan = this.flowChartPanZoom.getPan();
        // var sizes = this.flowChartPanZoom.getSizes();
        // var zoom = sizes.realZoom;

        // point.x = (x - pan.x) / zoom;
        // point.y = (y - pan.y)/zoom;
        // }
        return point;
    };


    public confirmDeleteAction() {
      let eventData = new EventDataModel();
      let componentSelected = false;

      this.nodes.forEach((node: NodeViewModel) => {
        if (!componentSelected) {
          componentSelected = node.selected();
        }
      });

      this.connections.forEach((conn: NodeViewModel) => {
        if (!componentSelected) {
          componentSelected = conn.selected();
        }
      });

      eventData.bool1 = componentSelected;
      eventData.eventName = 'confirmDelete';
      this.confirmDelete.emit(eventData);
    }
    //
    // Delete all nodes and connections that are selected.
    //
    deleteSelected() {

        let newNodeViewModels = [];
        let newNodeDataModels = [];
        let deletedNodeIds = [];
        let deletedNodes = [];
        let deletedConnectionsInfo = [];

        for (let nodeIndex = 0; nodeIndex < this.nodes.length; ++nodeIndex) {

            let node = this.nodes[nodeIndex];
            if (!node.selected()) {
                // Only retain non-selected nodes.
                newNodeViewModels.push(node);
                newNodeDataModels.push(node.data);
            } else {
                // Keep track of nodes that were deleted, so their connections can also
                // be deleted.
                deletedNodeIds.push(node.data.id);
                deletedNodes.push(node);
            }
        }

        let newConnectionViewModels = [];
        let newConnectionDataModels = [];

        //
        // Remove connections that are selected.
        // Also remove connections for nodes that have been deleted.
        //
        for (let connectionIndex = 0; connectionIndex < this.connections.length; ++connectionIndex) {

            let connection = this.connections[connectionIndex];
            if (!connection.selected() &&
                deletedNodeIds.indexOf(connection.data.source.nodeID) === -1 &&
                deletedNodeIds.indexOf(connection.data.dest.nodeID) === -1) {
                //
                // The nodes this connection is attached to, where not deleted,
                // so keep the connection.
                //
                newConnectionViewModels.push(connection);
                newConnectionDataModels.push(connection.data);
            } else {

                let sourceData = this.findNode(connection.data.source.nodeID);
                let destData = this.findNode(connection.data.dest.nodeID);
                deletedConnectionsInfo.push({
                    connection: connection,
                    sourceData: sourceData,
                    destData: destData,

                });
            }

        }

        //
        // Update nodes and connections.
        //
        this.nodes = newNodeViewModels;
        // this.nodes = newNodeDataModels;
        this.connections = newConnectionViewModels;
        // this.connections = newConnectionDataModels;

        let eventData = new EventDataModel();
        eventData.eventName = 'itemsDeleted';
        eventData.data = {
            deletedNodeIds: deletedNodeIds,
            deletedNodes: deletedNodes,
            deletedConnectionsInfo: deletedConnectionsInfo,
        };

        this.itemsDeleted.emit(eventData);

    }

    toggleOptions() {
        this.showOptions = !this.showOptions;
    }
}

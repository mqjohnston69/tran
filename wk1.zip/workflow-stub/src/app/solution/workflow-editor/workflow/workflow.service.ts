﻿
import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptionsArgs } from '@angular/http';
import { TreeNode } from 'primeng/primeng';
import { map, filter  } from 'rxjs/operators';


@Injectable()
export class WorkflowService {

  constructor(
    private http: Http,

  ) {}

  getFiles() {
    return this.http.get('./data/templatefiles.json')
      .toPromise()
      .then(res => <TreeNode[]>res.json().data);
  }
}

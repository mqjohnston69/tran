import { Component, OnInit } from '@angular/core';
import { TreeNode } from 'primeng/primeng';
import { WorkflowService } from './workflow.service';

@Component({
  selector: 'app-workflow-cmp',
  templateUrl: './workflow.component.html',
  styleUrls: ['./workflow.component.scss']
})
export class WorkflowComponent implements OnInit {
  workflow: any;

  // public properties
  files: TreeNode[];

  templateData = {
    'data': [
      {
        'label': 'Template Group',
        'data': 'qqq',
        'expandedIcon': 'fa-folder-open',
        'collapsedIcon': 'fa-folder',
        'expanded': true,
        'children': [
          {
            'label': 'State 1',
            'icon': 'fa fa-text-width',
            'data': 'xxx'
          },
          {
            'label': 'State 2',
            'icon': 'fa fa-text-width',
            'data': 'yyy'
          }
        ]
      }
    ]
  };

  constructor(
    public workflowService: WorkflowService
  ) { }

  ngOnInit() {

    // this.workflowService.getFiles().then(files => this.files = files);

    this.files = this.templateData.data;

    this.workflow = {
      'workflowID': 7,
      'workflowName': 'Admin QA Workflow',
      'workflowData': '',
      'description': null,
      'createDateTime': '2018-08-11T10:43:07.4635998-04:00',
      'updateDateTime': '2018-08-11T10:43:07.4635998-04:00',
      'timeStamp': '',
      'status': 'Not Running',
      'startTime': null,
      'nodes': [
        {
          'name': 'Initialized',
          'id': 1,
          'x': 75,
          'y': 150,
          'width': 125,
          'positionIndex': 1,
          'positionLevel': 1,
          'type': 'Init',
          'queueDetail': null,
          'inputConnectors': [],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        },
        {
          'name': 'Not Assigned',
          'id': 3,
          'x': 275,
          'y': 150,
          'width': 125,
          'positionIndex': 2,
          'positionLevel': 1,
          'type': 'State',
          'inputConnectors': [{ 'name': 'IN_1' }],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        },
        {
          'name': 'QA1 Complete',
          'id': 4,
          'x': 875,
          'y': 150,
          'width': 125,
          'positionIndex': 5,
          'positionLevel': 1,
          'type': 'State',
          'inputConnectors': [{ 'name': 'IN_1' }],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        },
        {
          'name': 'QA1 Initialized',
          'id': 6,
          'x': 675,
          'y': 150,
          'width': 125,
          'positionIndex': 4,
          'positionLevel': 1,
          'type': 'State',
          'inputConnectors': [{ 'name': 'IN_1' }],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        },
        {
          'name': 'QA2 Assigned',
          'id': 8,
          'x': 1075,
          'y': 150,
          'width': 125,
          'positionIndex': 6,
          'positionLevel': 1,
          'type': 'State',
          'inputConnectors': [{ 'name': 'IN_1' }],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        },
        {
          'name': 'QA1 In Progress',
          'id': 9,
          'x': 1075,
          'y': 300,
          'width': 125,
          'positionIndex': 5,
          'positionLevel': 2,
          'type': 'State',
          'inputConnectors': [{ 'name': 'IN_1' }],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        },
        {
          'name': 'QA1 Not Started',
          'id': 11,
          'x': 875,
          'y': 300,
          'width': 125,
          'positionIndex': 4,
          'positionLevel': 2,
          'type': 'State',
          'inputConnectors': [{ 'name': 'IN_1' }],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        },
        {
          'name': 'QA1 Complete',
          'id': 13,
          'x': 1275,
          'y': 300,
          'width': 125,
          'positionIndex': 6,
          'positionLevel': 2,
          'type': 'State',
          'inputConnectors': [{ 'name': 'IN_1' }],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        },
        {
          'name': 'QA1 Assigned',
          'id': 14,
          'x': 475,
          'y': 150,
          'width': 125,
          'positionIndex': 3,
          'positionLevel': 1,
          'type': 'State',
          'baseType': 'State',
          'inputConnectors': [{ 'name': 'IN_1' }],
          'outputConnectors': [{ 'name': 'OUT_1' }],
        }
      ],
      'connections': [
        {
          'name': '1_3',
          'source': {
            'nodeID': 1,
            'nodeX': 75,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 1,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 3,
            'nodeX': 275,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 2,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          }
        },
        {
          'name': '6_4',
          'source': {
            'nodeID': 6,
            'nodeX': 675,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 4,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 4,
            'nodeX': 875,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 5,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          }
        },
        {
          'name': '4_8',
          'source': {
            'nodeID': 4,
            'nodeX': 875,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 5,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 8,
            'nodeX': 1075,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 6,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          }
        },
        {
          'name': '11_9',
          'source': {
            'nodeID': 11,
            'nodeX': 675,
            'nodeY': 300,
            'nodeWidth': 125,
            'nodePositionIndex': 4,
            'nodePositionLevel': 2,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 9,
            'nodeX': 875,
            'nodeY': 300,
            'nodeWidth': 125,
            'nodePositionIndex': 5,
            'nodePositionLevel': 2,
            'connectorIndex': 0
          }
        },
        {
          'name': '9_13',
          'source': {
            'nodeID': 9,
            'nodeX': 875,
            'nodeY': 300,
            'nodeWidth': 125,
            'nodePositionIndex': 5,
            'nodePositionLevel': 2,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 13,
            'nodeX': 1075,
            'nodeY': 300,
            'nodeWidth': 125,
            'nodePositionIndex': 6,
            'nodePositionLevel': 2,
            'connectorIndex': 0
          }
        },
        {
          'name': '3_14',
          'source': {
            'nodeID': 3,
            'nodeX': 275,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 2,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 14,
            'nodeX': 475,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 3,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          }
        },
        {
          'name': '14_6',
          'source': {
            'nodeID': 14,
            'nodeX': 475,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 3,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 6,
            'nodeX': 675,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 4,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          }
        },
        {
          'name': '6_11',
          'source': {
            'nodeID': 6,
            'nodeX': 475,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 3,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 11,
            'nodeX': 675,
            'nodeY': 300,
            'nodeWidth': 125,
            'nodePositionIndex': 4,
            'nodePositionLevel': 2,
            'connectorIndex': 0
          }
        },
        {
          'name': '13_8',
          'source': {
            'nodeID': 13,
            'nodeX': 475,
            'nodeY': 150,
            'nodeWidth': 125,
            'nodePositionIndex': 3,
            'nodePositionLevel': 1,
            'connectorIndex': 0
          },
          'dest': {
            'nodeID': 8,
            'nodeX': 675,
            'nodeY': 300,
            'nodeWidth': 125,
            'nodePositionIndex': 4,
            'nodePositionLevel': 2,
            'connectorIndex': 0
          }
        },
      ],
      'desiredHeight': 600,
      'desiredWidth': 1600
    };
  }
}

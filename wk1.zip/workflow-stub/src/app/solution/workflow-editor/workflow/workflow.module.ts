import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpModule } from '@angular/http';
import { TreeModule } from 'primeng/primeng';
import { Http, Response, Headers, URLSearchParams, RequestOptionsArgs } from '@angular/http';
//import { Ng2DragDropModule } from 'ng2-drag-drop';

import { WorkflowRoutingModule } from './workflow-routing.module';
import { WorkflowComponent } from './workflow.component';
import { FlowChartModule } from '../components/flow-chart/flow-chart.module';
import { WorkflowService } from './workflow.service';


@NgModule({
    imports: [
        CommonModule,
        FlowChartModule,
        HttpModule,
        TreeModule,
        WorkflowRoutingModule,
        // Ng2DragDropModule.forRoot()
    ],
    declarations: [WorkflowComponent],
    providers: [ WorkflowService]
})
export class WorkflowModule {}

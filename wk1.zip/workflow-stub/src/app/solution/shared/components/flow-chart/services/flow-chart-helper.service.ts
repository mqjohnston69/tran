import { Injectable } from '@angular/core';
import { NodeViewModel } from '../node.view-model';

@Injectable()
export class FlowChartHelperService {

    constructor() {
        // Contructor
    }

    public getUniqueId(nodes): number {
        let num = 0;
        for (let i = 0; i < 1000; ++i) {
            num = (Math.floor((1 + Math.random()) * 0x10000)) * (-1);
            let index = nodes.findIndex(node => node.data.id === num);
            if (index < 0) {
                break;
            }
        }
        return num;
    }

    public getUniqueRouteId(routes): number {
        let num = 0;
        for (let i = 0; i < 1000; ++i) {
          num = (Math.floor((1 + Math.random()) * 0x10000)) * (-1);
          let index = routes.findIndex(route => route.routeID === num);
          if (index < 0) {
              break;
          }
        }
        return num;
      }

    //
    // Wrap the nodes data-model in a view-model.
    //
    createNodesViewModel(nodesDataModel) {
        let nodesViewModel = [];

        if (nodesDataModel) {
            for (let i = 0; i < nodesDataModel.length; ++i) {
                nodesViewModel.push(new NodeViewModel(nodesDataModel[i]));
            }
        }

        return nodesViewModel;
    }

    isEven(n) {
        return n % 2 === 0;
    }

    getSvgId() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }

}

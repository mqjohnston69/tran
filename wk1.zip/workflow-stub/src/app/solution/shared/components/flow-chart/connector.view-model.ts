//
// View model for a connector.
//
export class ConnectorViewModel {

    public data: any;
    public _parentNode: any;
    public _x: any;
    public _y: any;

    inputConnectors: any;
    outputConnectors: any;

    _selected = false;

    constructor(
        connectorDataModel: any,
        x: any,
        y: any,
        parentNode: any
    ) {

        this.data = connectorDataModel;
        this._parentNode = parentNode;
        this._x = x;
        this._y = y;
    }

    //
    // Name of the node.
    //
    name() {
        return this.data.name || '';
    }

    //
    // X coordinate of the node.
    //
    x() {
        return this._x;
    }

    //
    // Y coordinate of the node.
    //
    y() {
        return this._y;
    }

    //
    // The parent node that the connector is attached to.
    //
    parentNode() {
        return this._parentNode;
    }

}

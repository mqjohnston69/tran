export interface IEventData {
    eventName: string;
    dataNum1: number;
    dataNum2: number;
    bool1: boolean;
    dataStr1: string;
    dataStr2: string;
    data: any;
}

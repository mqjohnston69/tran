import { ConnectorViewModel } from './connector.view-model';

export class NodeViewModel {

    public data: any;

    public inputConnectors: any;
    public outputConnectors: any;

    _selected = false;

    constructor(
        nodeDataModel: any,
    ) {

        this.data = nodeDataModel;
        this.inputConnectors = this.createConnectorsViewModel(this.data.inputConnectors, 0, this);
		this.outputConnectors = this.createConnectorsViewModel(this.data.outputConnectors, this.data.width, this);
    }


    //
    // Name of the node.
    //
    name() {
        return this.data.name || '';
    };

    //
    // X coordinate of the node.
    //
    x() {
        return this.data.x;
    };

    public setx(value) {
        this.data.x = value;
    }


    //
    // Y coordinate of the node.
    //
    y() {
        return this.data.y;
    };

    public sety(value) {
        this.data.y = value;
    }

    //
    // Width of the node.
    //
    width() {
        return this.data.width;
    };

    //
    // Height of the node.
    //
    height() {

        var numConnectors = Math.max(this.inputConnectors.length, this.outputConnectors.length);
        if (numConnectors === 0)
            numConnectors = 1;

        return this.computeConnectorY(numConnectors);
        //return null;
    };

    //
    // Select the node.
    //
    select() {
        this._selected = true;
    };

    //
    // Deselect the node.
    //
    deselect() {
        this._selected = false;
    };

    //
    // Toggle the selection state of the node.
    //
    toggleSelected() {
        this._selected = !this._selected;
    };

    //
    // Returns true if the node is selected.
    //
    selected() {
        return this._selected;
    };


    createConnectorsViewModel (connectorDataModels, x, parentNode) {
		var viewModels = [];

		if (connectorDataModels) {
			for (var i = 0; i < connectorDataModels.length; ++i) {
				var connectorViewModel =
					new ConnectorViewModel(connectorDataModels[i], x, this.computeConnectorY(i), parentNode);
				viewModels.push(connectorViewModel);
			}
		}

		return viewModels;
	};

    computeConnectorY = function (connectorIndex) {
		return 40 + (connectorIndex * 35);
	};
}

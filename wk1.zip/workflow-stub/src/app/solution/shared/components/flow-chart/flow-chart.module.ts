import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgDragDropModule } from 'ng-drag-drop';
// import { DialogModule, ButtonModule, ToolbarModule, SliderModule } from 'primeng/primeng';

import { FlowChartComponent } from './flow-chart.component';
import { DraggableDirective } from './draggable.directive';
import { FlowChartHelperService } from './services/flow-chart-helper.service';

import { ZoomableDirective } from './d3/directives/zoomable.directive';
import { D3Service } from './d3/d3.service';

// import { ToasterModule } from 'angular2-toaster';

@NgModule({
    imports: [
        RouterModule,
        CommonModule,
        // ButtonModule,
        // DialogModule,
        FormsModule,
        // ToolbarModule,
        // SliderModule,
        // ToasterModule,
        NgDragDropModule.forRoot()
    ],
    declarations: [FlowChartComponent, DraggableDirective, ZoomableDirective],
    exports: [FlowChartComponent, DraggableDirective, ZoomableDirective],
    providers: [FlowChartHelperService, D3Service],
})

export class FlowChartModule { }

//
// View model for a connector.
//
export class ConnectionViewModel {

    public data: any;
    public source: any;
    public dest: any;

    _selected = false;

    constructor(
        connectionDataModel: any,
        sourceConnector: any,
        destConnector: any
    ) {

        this.data = connectionDataModel;
        this.source = sourceConnector;
        this.dest = destConnector;
    }

    name() {
        return this.data.name || '';
    }

    sourceCoordX() {
        return this.source.parentNode().x() + this.source.x();
    }

    sourceCoordY = function () {
        return this.source.parentNode().y() + this.source.y();
    };

    sourceCoord() {
        return {
            x: this.sourceCoordX(),
            y: this.sourceCoordY()
        };
    }

    sourceTangentX() {
        return this.computeConnectionSourceTangentX(this.sourceCoord(), this.destCoord());
    }

    sourceTangentY = function () {
        return this.computeConnectionSourceTangentY(this.sourceCoord(), this.destCoord());
    };

    destCoordX = function () {
        return this.dest.parentNode().x() + this.dest.x();
    };

    destCoordY = function () {
        return this.dest.parentNode().y() + this.dest.y();
    };

    destCoord = function () {
        return {
            x: this.destCoordX(),
            y: this.destCoordY()
        };
    };

    destTangentX = function () {
        return this.computeConnectionDestTangentX(this.sourceCoord(), this.destCoord());
    };

    destTangentY = function () {
        return this.computeConnectionDestTangentY(this.sourceCoord(), this.destCoord());
    };

    middleX = function (scale) {
        if (typeof (scale) === 'undefined') {
            scale = 0.5;
        }
        return this.sourceCoordX() * (1 - scale) + this.destCoordX() * scale;
    };

    middleY = function (scale) {
        if (typeof (scale) === 'undefined') {
            scale = 0.5;
        }
        return this.sourceCoordY() * (1 - scale) + this.destCoordY() * scale;
    };


    //
    // Select the connection.
    //
    select = function () {
        this._selected = true;
    };

    //
    // Deselect the connection.
    //
    deselect = function () {
        this._selected = false;
    };

    //
    // Toggle the selection state of the connection.
    //
    toggleSelected = function () {
        this._selected = !this._selected;
    };

    //
    // Returns true if the connection is selected.
    //
    selected = function () {
        return this._selected;
    };

    computeConnectionSourceTangentX = function (pt1, pt2) {

        return pt1.x + this.computeConnectionTangentOffset(pt1, pt2);
    };

    computeConnectionTangentOffset = function (pt1, pt2) {

        return (pt2.x - pt1.x) / 2;
    };


        // Compute the tangent for the bezier curve.
        //
        computeConnectionSourceTangentY = function (pt1, pt2) {
            return pt1.y;
        };

        //
        // Compute the tangent for the bezier curve.
        //
        computeConnectionSourceTangent = function(pt1, pt2) {
            return {
                x: this.computeConnectionSourceTangentX(pt1, pt2),
                y: this.computeConnectionSourceTangentY(pt1, pt2),
            };
        };

        //
        // Compute the tangent for the bezier curve.
        //
        computeConnectionDestTangentX = function (pt1, pt2) {

            return pt2.x - this.computeConnectionTangentOffset(pt1, pt2);
        };

        //
        // Compute the tangent for the bezier curve.
        //
        computeConnectionDestTangentY = function (pt1, pt2) {
            return pt2.y;
        };

        //
        // Compute the tangent for the bezier curve.
        //
        computeConnectionDestTangent = function(pt1, pt2) {
            return {
                x: this.computeConnectionDestTangentX(pt1, pt2),
                y: this.computeConnectionDestTangentY(pt1, pt2),
            };
        };
}

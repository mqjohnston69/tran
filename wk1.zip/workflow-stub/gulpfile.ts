
import * as gulp from 'gulp';
import * as util from 'gulp-util';
// import * as path from 'path';
// import * as _ from 'lodash';
// import * as fs from 'fs';

// let replace = require('gulp-replace');

const dateformat = require('dateformat');

import * as rename from 'gulp-rename';
const template = require('gulp-template');

gulp.src('node_modules/moment/moment.js')
  .pipe(gulp.dest('./node_modules'));



let hRule = " \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 \u0336 ";


/****************************************************************************************************************/
/*      component generation       */
/****************************************************************************************************************/
gulp.task('gen-component-stub', (done: any) =>  {

  const names = getNameVariants(args.name);
  const currDate = dateformat( new Date(), 'dd mmm yyyy');

  // util.log('The processed args object is:');
  // util.log(args);

  const cmpData = {
    componentName: args.name,
    componentNameCamelCase: names.nameCamelCase,
    componentNameTitleCase: names.nameTitleCase,
    componentNameCaps: names.nameAllCaps,
    dateStamp: currDate
  };

  const inFilePath = './tools/templates/blank/';
  const outFilePath = './src/app/layout/';

  const templateFiles = [{
    'fileName': 'empty.component.html'
  },
    {
      'fileName': 'empty.component.scss'
    },
    {
      'fileName': 'empty.component.spec.ts'
    },
    {
      'fileName': 'empty.component.ts'
    },
    {
      'fileName': 'empty.module.spec.ts'
    },
    {
      'fileName': 'empty.module.ts'
    },
    {
      'fileName': 'empty-routing.module.ts'
    }
      ];


  let i = 0;
  let result = [];



  for (i = 0; i < templateFiles.length; i++) {

    result.push(
        gulp
            .src(inFilePath + templateFiles[i].fileName)
            .pipe(template(cmpData).on('error', function(err: any) { util.log("ERROR in executing template " ); util.log(err) }))
            .pipe(rename(templateFiles[i].fileName.replace(/empty/ig, args.name)).on('error', function(err: any) { util.log("ERROR in renaming"); util.log(err) }))
            .pipe(gulp.dest(outFilePath + args.name))
    );
  }

  return result;

});

gulp.task('gen-simple-solution', (done: any) =>  {

  const names = getNameVariants(args.name);
  const currDate = dateformat( new Date(), 'dd mmm yyyy');

  // util.log('The processed args object is:');
  // util.log(args);

  const cmpData = {
    componentName: args.name,
    componentNameCamelCase: names.nameCamelCase,
    componentNameTitleCase: names.nameTitleCase,
    componentNameCaps: names.nameAllCaps,
    dateStamp: currDate
  };

  const inFilePath = './tools/templates/simple-solution/';
  const outFilePath = './src/app/solution/';

  const templateFiles = [{
    'fileName': 'empty.component.html'
  },
    {
      'fileName': 'empty.component.scss'
    },
    {
      'fileName': 'empty.component.spec.ts'
    },
    {
      'fileName': 'empty.component.ts'
    },
    {
      'fileName': 'empty.module.spec.ts'
    },
    {
      'fileName': 'empty.module.ts'
    },
    {
      'fileName': 'empty-routing.module.ts'
    }
      ];


  let i = 0;
  let result = [];

  for (i = 0; i < templateFiles.length; i++) {

    result.push(
        gulp
            .src(inFilePath + templateFiles[i].fileName)
            .pipe(template(cmpData).on('error', function(err: any) { util.log("ERROR in executing template " ); util.log(err) }))
            .pipe(rename(templateFiles[i].fileName.replace(/empty/ig, args.name)).on('error', function(err: any) { util.log("ERROR in renaming"); util.log(err) }))
            .pipe(gulp.dest(outFilePath + args.name))
    );
  }

  return result;

});

gulp.task('gen-solution-page', (done: any) =>  {

  const names = getNameVariants(args.name);
  const currDate = dateformat( new Date(), 'dd mmm yyyy');

  // util.log('The processed args object is:');
   util.log(args);


  return null;

});

/****************************************************************************************************************/
// Utility Functions


// creates the various forms of the component name from the raw name:
// replaces dashes with camel case , title case, all caps, etc.
function getNameVariants(name: string) {

  // split string on dash or dot to create the name parts.
  // TODO: probably need to remove illegal chars.
  const tokens = name.split(/[\.\-]/);
  let i = 0;
  let camelCaseItems = [], titleCaseItems = [], capsItems = [];
  const makeTitle = function(txt: string) {return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); };

  for (i = 0; i < tokens.length; i++) {

    if (i === 0) {
      camelCaseItems.push(tokens[i].toLowerCase());
    } else {
      camelCaseItems.push(makeTitle(tokens[i]));
    }

    capsItems.push(tokens[i].toUpperCase());
    titleCaseItems.push(makeTitle(tokens[i]));
  }

  return {nameAllCaps: capsItems.join(''), nameCamelCase: camelCaseItems.join(''), nameTitleCase: titleCaseItems.join("") }

}


// parse cmd line args; this works when the arg format is: -name value
// https://www.sitepoint.com/pass-parameters-gulp-tasks/
const args: any = (function(argList) {

  let arg: any = {}, a, opt, thisOpt, curOpt;

  //the first three args are: node, gulp and the task name; so we can skip those in the loop
  for (a = 3; a < argList.length; a++) {
    thisOpt = argList[a].trim();
    opt = thisOpt.replace(/^\-+/, '');

    if (opt === thisOpt) {
      // argument value
      if (curOpt) arg[curOpt] = opt;
      curOpt = null;
    } else {
      // argument name
      curOpt = opt;
      arg[curOpt] = true;
    }
  }

  return arg;

})(process.argv);

//gulputil.log("The processed args object is:");
//gulputil.log(args);



/**********************************************************************************************************/



